# Modelo de Reclamações

Este arquivo ZIP contém dados relacionados a reclamações de clientes.

## Conteúdo

- **reclamacoes.csv**: Um arquivo CSV contendo as reclamações registradas, com as seguintes colunas:
  - Id_recla: Identificador da reclamação
  - Nm_clie: Nome do cliente
  - Dt_recla: Data da reclamação
  - Origem_recla: Origem da reclamação (ex: Email, Telefone)
  - Solucionada_recla: Status de solução (true/false)
  - Assunto_recla: Assunto da reclamação
  - Id_fun: Identificador do funcionário responsável

- **logs/**: Diretório contendo logs relacionados às reclamações. Cada arquivo de log contém informações sobre as atividades realizadas durante o processamento das reclamações.

## Como Usar

Para utilizar os dados das reclamações, abra o arquivo `reclamacoes.csv` em um editor de planilhas ou em um programa que suporte leitura de arquivos CSV.

Os arquivos de log podem ser consultados para verificar o histórico de processamento das reclamações.
